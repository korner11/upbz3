package upb.z3;

import javax.swing.JFrame;


public class PasswordSecurity2 {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        GUI okno = new GUI();
        okno.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        okno.setVisible(true);
        okno.setResizable(false);
        okno.setLocationRelativeTo(null);
    }
    
}
